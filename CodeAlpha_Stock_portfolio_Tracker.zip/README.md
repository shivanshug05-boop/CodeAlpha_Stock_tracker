# Stock Portfolio Tracker

A simple Python mini project to calculate stock investments.

## Features

- Uses a hardcoded dictionary for stock prices
- Takes stock name and quantity from the user
- Calculates investment using Price × Quantity
- Supports multiple stocks
- Handles invalid stock names and quantities
- Calculates total investment
- Saves portfolio details to a CSV file

## Technologies Used

- Python
- CSV File Handling

## How to Run

```bash
python stock_portfolio.py
```

Enter the stock name and quantity when prompted.

## Example

```text
AAPL × 5 = $900
TSLA × 2 = $500

Total Investment = $1400
```

## Available Stocks

| Stock | Hardcoded Price |
|---|---:|
| AAPL | $180 |
| TSLA | $250 |
| GOOGL | $150 |
| MSFT | $420 |
| AMZN | $190 |
| META | $550 |
| NVDA | $140 |
| NFLX | $700 |
| AMD | $160 |
| INTC | $25 |

> The prices are hardcoded example values for this Python mini project. They are not live market prices.
