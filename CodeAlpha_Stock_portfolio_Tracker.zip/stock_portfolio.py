stock_prices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOGL": 150,
    "MSFT": 420,
    "AMZN": 190,
    "META": 550,
    "NVDA": 140,
    "NFLX": 700,
    "AMD": 160,
    "INTC": 25
}

portfolio = []
total_investment = 0

print("========== STOCK PORTFOLIO ==========")
print("Available stocks:")
print(", ".join(stock_prices.keys()))

while True:
    stock = input("\nEnter stock name: ").upper()

    if stock not in stock_prices:
        print("Stock not available. Please enter a valid stock.")
        continue

    while True:
        try:
            quantity = int(input("Enter quantity: "))

            if quantity <= 0:
                print("Quantity must be greater than 0.")
                continue

            break

        except ValueError:
            print("Please enter a valid number.")

    price = stock_prices[stock]
    investment = price * quantity

    portfolio.append([stock, quantity, price, investment])
    total_investment += investment

    print(f"{stock} added successfully!")
    print(f"Investment: ${investment}")

    more = input("Add another stock? (yes/no): ").lower()

    if more != "yes":
        break

print("\n========== YOUR PORTFOLIO ==========")

for stock, quantity, price, investment in portfolio:
    print(
        f"{stock}    {quantity} shares    "
        f"${price}    ${investment}"
    )

print("-------------------------------------")
print(f"Total Investment: ${total_investment}")

with open("portfolio.csv", "w") as file:
    file.write("Stock,Quantity,Price,Investment\n")

    for stock, quantity, price, investment in portfolio:
        file.write(f"{stock},{quantity},{price},{investment}\n")

print("\nPortfolio saved to portfolio.csv")
